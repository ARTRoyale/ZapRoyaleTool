<strong>Warning:</strong> I recommend to use python 3.5.
<h2>Py2SC 1.0.4</h2>
<p>Run with (compress files):</p>
<pre>
python sc_compress.py
</pre>

<p>Run with (decompress files):</p>
<pre>
python sc_decompress.py
</pre>

<h2>Installation</h2>
<p>Install requirements with:</p>
<pre>
python install -r requirements.txt
</pre>
